from flask_login import login_required, current_user, LoginManager, UserMixin, login_user, logout_user
from flask import Flask, render_template, request, send_file, jsonify, flash, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
import pandas as pd
import os, random, io
from datetime import datetime
from faker import Faker
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors
from docx import Document
from flask import jsonify, send_file
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"
fake = Faker()

# -------------------------------------------------
# DATABASE & LOGIN SETUP
# -------------------------------------------------
# app.py mein ye change karein
# Isme colon (:) ka dhyan rakhein localhost ke baad
# Is line ko copy karke app.py mein paste karein
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@127.0.0.1:3306/datamimic_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# --- Is line ko dhundo: class User(db.Model, UserMixin): ---
# Us poore section ko isse replace karo:

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(100))
    phone = db.Column(db.String(15))
    dob = db.Column(db.Date)
    role = db.Column(db.String(50), default='Student')
    # History se link karne ke liye
    history = db.relationship('UserDownloads', backref='owner', lazy=True)

class UserDownloads(db.Model):
    __tablename__ = 'user_downloads'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    file_name = db.Column(db.String(255))
    domain = db.Column(db.String(100))
    format = db.Column(db.String(10))
    download_date = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    # Purana: return User.query.get(int(user_id))
    return db.session.get(User, int(user_id)) # Naya aur sahi tarika

with app.app_context():
   # db.drop_all()   # Ye purani galat table ko delete kar dega
    db.create_all() # Ye naye columns (email, phone, dob) ke sath nayi table banayega
    print("Database Tables Re-created Successfully!")

# -------------------------------------------------
# 1. DOMAIN FIELDS (Full List Preserved)
# -------------------------------------------------
DOMAIN_FIELDS = {
    "Hospital": ["Patient Name","Age","Gender","Disease","Doctor","Admission Date","Email","Phone"],
    "College": ["Student Name","Roll No","Course","Semester","Marks","Email","Phone"],
    "School": ["Student Name","Class","Section","Marks","Teacher","Email"],
    "Office": ["Employee Name","Emp ID","Department","Salary","Joining Date","Email"],
    "Banking": ["Account Holder","Account No","Branch","Balance","Email","Phone"],
    "Insurance": ["Policy Holder","Policy No","Policy Type","Premium","Agent","Email"],
    "E-Commerce": ["Order ID","Product","Price","Quantity","Customer","Status"],
    "Retail": ["Item Name","Category","Price","Stock","Supplier"],
    "Real Estate": ["Owner Name","Property Type","City","Price","Area"],
    "Travel": ["Customer Name","Source","Destination","Date","Fare"],
    "Hotel": ["Guest Name","Room No","Check-in Date","Check-out Date","Bill"],
    "Restaurant": ["Customer Name","Dish","Price","Quantity","Payment Mode"],
    "Logistics": ["Shipment ID","Source","Destination","Weight","Status"],
    "Telecom": ["Customer Name","Mobile No","Plan","Usage","Bill Amount"],
    "Government": ["Citizen Name","ID Number","Scheme","Department","Status"],
    "Social Media": ["Username","Platform","Followers","Posts","Engagement"],
    "Sports": ["Player Name","Sport","Team","Matches","Score"],
    "Entertainment": ["Artist Name","Category","Project","Budget","Release Date"],
    "Education": ["Student Name","Course","Institute","Duration","Fees"],
    "Medical Lab": ["Patient Name","Test Name","Result","Doctor","Date"],
    "Corporate": ["Client Name","Project","Budget","Manager","Deadline"],
    "Software Agency": ["Project Name", "Client", "Tech Stack", "Budget", "Manager", "Status"],
    "Gym / Fitness": ["Member Name", "Age", "Gender", "Membership Plan", "Trainer", "Joining Date"],
    "Pharmacy": ["Medicine Name", "Category", "Dosage", "Price", "Stock", "Supplier"],
    "Airport Authority": ["Flight No", "Airline", "Source", "Destination", "Terminal", "Status"],
    "Police Records": ["Case ID", "Crime Type", "Officer Name", "Area", "Status", "Date"],
    "Law Firm": ["Case No", "Client Name", "Lawyer", "Case Category", "Hearing Date", "Status"],
    "Social Work / NGO": ["Volunteer Name", "Cause", "Donation Amount", "Location", "Impact Status"],
    "Sports Club": ["Player Name", "Sport", "Coach Name", "Membership Type", "Join Date"],
    "Movie Theater": ["Movie Title", "Screen No", "Show Time", "Tickets Sold", "Revenue"],
    "Public Library": ["Book Title", "Author", "Member Name", "Issue Date", "Return Date"],
    "Construction Site": ["Site Name", "Location", "Material", "Total Cost", "Manager Name", "Status"]
}

# -------------------------------------------------
# 2. DATA GENERATION LOGIC
# -------------------------------------------------
def generate_value(field):
    f_lower = field.lower()
    if any(x in field for x in ["Name", "Holder", "Owner", "Username", "Artist", "Citizen", "Player", "Member", "Volunteer", "Lawyer", "Officer", "Coach", "Manager", "Author", "Client", "Trainer"]):
        return fake.name()
    if "Age" in field: return random.randint(18, 70)
    if "Gender" in field: return random.choice(["Male","Female"])
    if any(x in f_lower for x in ["salary", "price", "bill", "fees", "budget", "balance", "fare", "premium", "cost", "revenue", "donation", "amount"]):
        return random.randint(1000, 100000)
    if any(x in f_lower for x in ["date", "deadline", "check-in", "check-out", "admission", "hearing", "issue", "return", "joining", "show time"]):
        return fake.date()
    if "Status" in field: return random.choice(["Active","Pending","Completed", "Closed", "On-Going", "In-Transit"])
    if any(x in f_lower for x in ["id", "no", "roll", "account", "shipment", "flight", "case", "license", "screen"]):
        return fake.bothify(text='??-####').upper()
    if "Medicine" in field: return random.choice(["Paracetamol", "Amoxicillin", "Cetirizine", "Ibuprofen"])
    if "Tech Stack" in field: return random.choice(["React", "Python", "Flutter", "Node.js", "Django"])
    if "Crime" in field: return random.choice(["Theft", "Cyber Fraud", "Assault", "Traffic Violation"])
    if "Material" in field: return random.choice(["Cement", "Steel", "Bricks", "Wood"])
    if "Sport" in field: return random.choice(["Cricket", "Football", "Tennis", "Badminton"])
    if "Cause" in field: return random.choice(["Education", "Poverty", "Healthcare", "Environment"])
    if any(x in f_lower for x in ["source", "destination", "city", "location", "area", "branch"]): return fake.city()
    if "Movie" in field: return random.choice(["Inception", "Avatar", "Titanic", "The Dark Knight"])
    if "Book" in field: return random.choice(["The Alchemist", "Harry Potter", "Deep Work", "Atomic Habits"])
    if "Email" in field: return fake.email()
    if "Phone" in field or "Mobile" in field: return fake.phone_number()
    return fake.word().title()

def generate_dataset(domain, rows, config=None):
    # 1. Domain dhundne ka sabse sahi tareeka (Case Insensitive)
    fields = None
    target_domain = domain.strip().lower()
    for key in DOMAIN_FIELDS.keys():
        if key.lower() == target_domain:
            fields = DOMAIN_FIELDS[key]
            break
    
    if not fields:
        print(f"DEBUG: Domain '{domain}' not found!")
        return pd.DataFrame() 

    # 2. Filter Logic: Sirf tabhi filter karo jab config mein koi 'True' value ho
    # Agar user ne kuch tick nahi kiya, toh saare fields dikhao
    if config and any(config.values()):
        filtered_fields = []
        numeric_keywords = ["Salary","Price","Bill","Fees","Budget","Balance","Fare","Marks","Quantity","Age","Premium", "Cost", "Revenue", "Donation"]
        
        for f in fields:
            f_low = f.lower()
            # Agar Email field hai aur email checkbox OFF hai, toh skip karo
            if "email" in f_low and not config.get("include_email"): continue
            # Agar Phone field hai aur phone checkbox OFF hai, toh skip karo
            if ("phone" in f_low or "mobile" in f_low) and not config.get("include_phone"): continue
            # Agar Date field hai aur date checkbox OFF hai, toh skip karo
            if ("date" in f_low or "deadline" in f_low or "joining" in f_low) and not config.get("include_date"): continue
            # Numeric fields check
            if any(key.lower() in f_low for key in numeric_keywords) and not config.get("include_numeric"): continue
            # Text/Name fields check
            if ("name" in f_low or "status" in f_low or "holder" in f_low) and not config.get("include_text"): continue
            
            filtered_fields.append(f)
        
        # Agar filtering ke baad list khali ho jaye (safety check)
        if filtered_fields:
            fields = filtered_fields

    # 3. Data Generation
    data = []
    for _ in range(rows):
        row = {field: generate_value(field) for field in fields}
        data.append(row)
        
    return pd.DataFrame(data)

# -------------------------------------------------
# 3. FILE GENERATORS
# -------------------------------------------------
def generate_pdf(df, path):
    doc = SimpleDocTemplate(path, pagesize=letter)
    elements = []
    data = [df.columns.tolist()] + df.values.tolist()
    t = Table(data)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                           ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                           ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                           ('GRID', (0, 0), (-1, -1), 1, colors.black)]))
    elements.append(t)
    doc.build(elements)

def generate_word(df, path):
    doc = Document()
    doc.add_heading('Generated DataMimic Report', 0)
    table = doc.add_table(rows=1, cols=len(df.columns))
    hdr_cells = table.rows[0].cells
    for i, col in enumerate(df.columns):
        hdr_cells[i].text = col
    for index, row in df.iterrows():
        row_cells = table.add_row().cells
        for i, val in enumerate(row):
            row_cells[i].text = str(val)
    doc.save(path)

# -------------------------------------------------
# 4. AUTH ROUTES
# -------------------------------------------------
@app.route("/")
def home():
    if not current_user.is_authenticated:
        return redirect(url_for('login'))
    return redirect(url_for('dashboard_view'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        try:
            new_user = User(username=username, password=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('login'))
        except:
            return "Username already exists!"
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard_view'))
        else:
            return "Invalid Login!"
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# -------------------------------------------------
# 5. GENERATOR & PROFILE ROUTES
# -------------------------------------------------
# -------------------------------------------------


# <--- YAHA PASTE KARO START --->

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        current_user.email = request.form.get('email')
        current_user.phone = request.form.get('phone')
        dob_str = request.form.get('dob')
        if dob_str:
            try:
                current_user.dob = datetime.strptime(dob_str, '%Y-%m-%d')
            except: pass
        current_user.role = request.form.get('role')
        db.session.commit()
        return redirect(url_for('profile'))

    # History aur Chart ke liye stats nikalna
    history = UserDownloads.query.filter_by(user_id=current_user.id).order_by(UserDownloads.download_date.desc()).all()
    
    # Chart logic: Kaunse domain se kitni baar download kiya
    domain_counts = {}
    for h in history:
        domain_counts[h.domain] = domain_counts.get(h.domain, 0) + 1
    
    return render_template('profile.html', 
                           user=current_user, 
                           history=history,
                           stats_labels=list(domain_counts.keys()),
                           stats_values=list(domain_counts.values()))


# -------------------------------------------------
# 5. GENERATOR & PREVIEW ROUTES (FIXED)
# -------------------------------------------------

@app.route("/generator")
@login_required
def dashboard_view():
    return render_template("index.html", domains=list(DOMAIN_FIELDS.keys()))

@app.route('/preview', methods=['POST'])
@login_required
def preview_view():
    try:
        domain = request.form.get('domain')
        # Preview ke liye config=None bhej rahe hain taaki saare fields dikhein
        df = generate_dataset(domain, 5, config=None) 
        
        if df.empty:
            return jsonify({'status': 'error', 'message': f'Domain "{domain}" nahi mila!'})
        
        return jsonify({
            'status': 'success',
            'columns': df.columns.tolist(),
            'preview': df.to_dict(orient='records')
        })
    except Exception as e:
        print(f"Preview Error: {e}")
        return jsonify({'status': 'error', 'message': str(e)})

@app.route("/generate", methods=["POST"])
@login_required
def generate():
    try:
        domain = request.form.get("domain", "").strip()
        rows_str = request.form.get("records", "10")
        rows = int(rows_str) if rows_str.isdigit() else 10
        output_format = request.form.get("format", "csv").lower()
        
        # Checkbox config
        config = {
            'include_text': request.form.get('include_text') == 'on',
            'include_numeric': request.form.get('include_numeric') == 'on',
            'include_date': request.form.get('include_date') == 'on',
            'include_email': request.form.get('include_email') == 'on',
            'include_phone': request.form.get('include_phone') == 'on'
        }

        # Dataset Generation
        df = generate_dataset(domain, rows, config=config)
        
        if df.empty:
            return f"Error: Data generate nahi ho paya! Domain '{domain}' check karein.", 404

        # Folder setup
        os.makedirs("generated_data", exist_ok=True)
        safe_name = domain.replace("/", "_").replace(" ", "_")
        file_name = f"mimic_{safe_name}.{output_format}"
        path = os.path.join("generated_data", file_name)
        
        # 10 Formats Handling
        if output_format == "csv": 
            df.to_csv(path, index=False)
        elif output_format == "xlsx": 
            df.to_excel(path, index=False)
        elif output_format == "json": 
            df.to_json(path, orient="records", indent=4)
        elif output_format == "pdf": 
            generate_pdf(df, path)
        elif output_format == "docx": 
            generate_word(df, path)
        elif output_format == "xml":
            df.to_xml(path, index=False)
        elif output_format == "html":
            df.to_html(path, index=False, classes="table table-striped")
        elif output_format == "md":
            df.to_markdown(path, index=False)
        elif output_format == "txt":
            with open(path, "w") as f: f.write(df.to_string(index=False))
        elif output_format == "sql":
            table_name = safe_name.lower()
            with open(path, "w") as f:
                f.write(f"CREATE TABLE {table_name} (\n")
                f.write(",\n".join([f"  {col.replace(' ', '_')} TEXT" for col in df.columns]))
                f.write("\n);\n\n")
                for _, row in df.iterrows():
                    vals = ", ".join([f"'{str(v).replace('\'', '\'\'')}'" for v in row.values])
                    f.write(f"INSERT INTO {table_name} VALUES ({vals});\n")

        # History save
        new_history = UserDownloads(
            domain=domain, 
            format=output_format, 
            file_name=file_name, 
            user_id=current_user.id
        )
        db.session.add(new_history)
        db.session.commit()
        
        return send_file(path, as_attachment=True)

    except Exception as e:
        print(f"CRITICAL ERROR: {e}")
        return f"System Error: {str(e)}", 500

if __name__ == "__main__":
    app.run(debug=True)