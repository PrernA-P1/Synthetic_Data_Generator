// Global variables charts ko store karne ke liye
let genderChartInstance = null;
let trendChartInstance = null;

document.addEventListener('DOMContentLoaded', function() {
    // 1. Elements Select Karna
    const domainSelect = document.getElementById('domainSelect');
    const recordsInput = document.getElementById('records');
    const formatSelect = document.getElementById('formatSelect');
    const downloadBtn = document.getElementById('downloadBtn');
    // Note: HTML mein table ki ID "previewTable" hai, hum uske body ko target karenge
    const tableBody = document.getElementById('tableBody');
    const tableHeader = document.getElementById('tableHeader');
    const analyticsTabBtn = document.getElementById('analytics-tab');
    
    // Naya Element: Search Input ke liye
    const domainSearch = document.getElementById('domainSearch');

    // --- 2. UPDATED CHART LOGIC (Premium Doughnut Look) ---
function updateCharts(analytics) {
    const textColor = 'white'; //
    const primaryCyan = '#00d2ff'; // Aapki image ka cyan color
    const primaryPurple = '#6200ee'; // Deep purple theme color

    // Gender/Domain Distribution (Doughnut Chart - PIE ki jagah)
    const genderCtx = document.getElementById('genderChart');
    if (genderCtx && analytics.gender) {
        if (window.genderChartInstance) window.genderChartInstance.destroy();
        
        window.genderChartInstance = new Chart(genderCtx, {
            type: 'doughnut', // Wahi premium gol look
            data: {
                labels: Object.keys(analytics.gender),
                datasets: [{
                    data: Object.values(analytics.gender),
                    backgroundColor: [primaryCyan, primaryPurple, '#bb86fc', '#03dac6'], //
                    borderWidth: 0,
                    hoverOffset: 15,
                    borderRadius: 5
                }]
            },
            options: { 
                responsive: true, 
                maintainAspectRatio: false,
                cutout: '70%', // Beech ka gap doughnut ke liye
                plugins: { 
                    legend: { 
                        position: 'bottom',
                        labels: { 
                            color: textColor, 
                            font: { size: 14, weight: '600', family: 'Poppins' }, // Bade fonts
                            padding: 20 
                        } 
                    } 
                }
            }
        });
    }

    // Numeric Trends (Bar Chart - Styled for Dark Theme)
    const trendCtx = document.getElementById('trendChart');
    if (trendCtx && analytics.trends) {
        if (window.trendChartInstance) window.trendChartInstance.destroy();

        window.trendChartInstance = new Chart(trendCtx, {
            type: 'bar',
            data: {
                labels: analytics.labels || [],
                datasets: [{
                    label: analytics.chart_title || 'Value Distribution',
                    data: analytics.trends,
                    backgroundColor: primaryCyan, // Consistent cyan color
                    borderRadius: 8,
                    barThickness: 25 // Sahi alignment ke liye
                }]
            },
            options: { 
                responsive: true, 
                maintainAspectRatio: false,
                scales: {
                    y: { 
                        ticks: { color: textColor, font: { size: 12 } }, 
                        grid: { color: 'rgba(255,255,255,0.05)' } 
                    },
                    x: { 
                        ticks: { color: textColor, font: { size: 12 } }, 
                        grid: { display: false } 
                    }
                },
                plugins: { 
                    legend: { 
                        labels: { color: textColor, font: { weight: '600' } } 
                    } 
                }
            }
        });
    }
}

    // --- 3. HISTORY UPDATE LOGIC ---
    function addToHistory(domain, format, records) {
        const historyBody = document.getElementById('historyBody');
        const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        // "Welcome" text ko hatane ke liye agar pehli bar data aa raha hai
        if (historyBody.innerText.includes("Welcome")) historyBody.innerHTML = "";

        const item = `
            <div class="history-item">
                <div class="d-flex justify-content-between fw-bold">
                    <span>${domain}</span>
                    <span class="badge bg-primary text-uppercase">${format}</span>
                </div>
                <div class="d-flex justify-content-between mt-1 small text-white-50">
                    <span>${records} rows</span>
                    <span>${time}</span>
                </div>
            </div>`;
        historyBody.insertAdjacentHTML('afterbegin', item);
    }

    // --- 4. PREVIEW FUNCTION ---
    async function updatePreview() {
        if (!tableBody) return;
        
        tableBody.innerHTML = '<tr><td colspan="10" class="text-center p-4">Loading preview...</td></tr>';

        const payload = {
            domain: domainSelect.value,
            records: 5, // Preview ke liye hamesha 5
            // Checkboxes ki value check karna
            include_text: document.querySelector('[name="include_text"]')?.checked || false,
            include_numeric: document.querySelector('[name="include_numeric"]')?.checked || false,
            include_date: document.querySelector('[name="include_date"]')?.checked || false,
            include_email: document.querySelector('[name="include_email"]')?.checked || false,
            include_phone: document.querySelector('[name="include_phone"]')?.checked || false
        };

        try {
            const res = await fetch('/preview', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            });
            const data = await res.json();

            if (data.status === "success") {
                // Headers update karein
                tableHeader.innerHTML = `<tr>${data.columns.map(c => `<th>${c}</th>`).join('')}</tr>`;
                
                // Body update karein
                tableBody.innerHTML = data.preview.map(row => 
                    `<tr>${data.columns.map(c => `<td>${row[c] || ''}</td>`).join('')}</tr>`
                ).join('');

                // Analytics Tab update karein
                if (data.analytics) updateCharts(data.analytics);
            }
        } catch (err) {
            tableBody.innerHTML = '<tr><td colspan="10" class="text-center text-danger">Failed to load preview.</td></tr>';
            console.error("Preview Error:", err);
        }
    }

    // --- 5. DOWNLOAD FUNCTION ---
    if(downloadBtn) {
        downloadBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            const originalText = downloadBtn.innerHTML;
            downloadBtn.innerHTML = "⏳ Generating...";
            downloadBtn.disabled = true;

            const formData = new FormData();
            formData.append('domain', domainSelect.value);
            formData.append('records', recordsInput.value);
            formData.append('format', formatSelect.value);

            // Checkboxes ka data add karna
            document.querySelectorAll('.form-check-input').forEach(cb => {
                if(cb.checked) formData.append(cb.name, 'on');
            });

            try {
                const res = await fetch('/generate', { method: 'POST', body: formData });
                if (res.ok) {
                    const blob = await res.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `DataMimic_${domainSelect.value.replace(/\s+/g, '_')}.${formatSelect.value}`;
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                    
                    // 🔥 YAHAN CHANGE HAI: Purana addToHistory hatakar real-time update call kiya
                    setTimeout(refreshHistorySidebar, 1000); 
                }
            } catch (err) {
                alert("Download failed. Check console.");
            } finally {
                downloadBtn.innerHTML = originalText;
                downloadBtn.disabled = false;
            }
        });
    }

    // --- YE NAYA FUNCTION HAI: Ise "Download Function" ke JUST NICHE paste karein ---
    function refreshHistorySidebar() {
        fetch('/dashboard') 
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newHistory = doc.getElementById('historyBody').innerHTML;
                
                // Sidebar ko naye data se update karein
                const historyBody = document.getElementById('historyBody');
                if (historyBody) {
                    historyBody.innerHTML = newHistory;
                }
            })
            .catch(err => console.error("History refresh failed:", err));
    }

    // --- 6. SMART SEARCH LOGIC (Dono merge karte waqt ye naya block hai) ---
    if (domainSearch) {
        const domainOptions = Array.from(domainSelect.options);
        domainSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            domainSelect.innerHTML = ''; 
            
            const filteredOptions = domainOptions.filter(option => 
                option.text.toLowerCase().includes(searchTerm)
            );

            filteredOptions.forEach(opt => domainSelect.add(opt));

            if (filteredOptions.length > 0) {
                domainSelect.selectedIndex = 0;
                updatePreview(); // Search karte hi preview update hoga
            }
        });
    }

    // --- 7. EVENT LISTENERS ---
    domainSelect.addEventListener('change', updatePreview);
    recordsInput.addEventListener('change', updatePreview);
    document.querySelectorAll('.form-check-input').forEach(cb => {
        cb.addEventListener('change', updatePreview);
    });

    // Chart.js bug fix: Tab change par chart gayab ho jata hai, use resize/update karein
    if (analyticsTabBtn) {
        analyticsTabBtn.addEventListener('shown.bs.tab', function() {
            setTimeout(() => { // 100ms ka gap dete hain taaki tab poora khul jaye
                if (genderChartInstance) {
                    genderChartInstance.resize();
                    genderChartInstance.update();
                }
                if (trendChartInstance) {
                    trendChartInstance.resize();
                    trendChartInstance.update();
                }
            }, 100);
        });
    }

    // Initialize first look
    updatePreview(); 
});