import pandas as pd
from faker import Faker
import random
import os
# domain_config se DOMAINS import kar rahe hain
try:
    from domain_config import DOMAINS
except ImportError:
    from core.domain_config import DOMAINS

fake = Faker()

def generate_dataset(domain_name, rows=10):
    # Sabse pehle check karein ki domain dictionary mein hai ya nahi
    # Hum 'Gym / Fitness' jaise names ko handle karne ke liye direct check kar rahe hain
    columns = DOMAINS.get(domain_name)
    
    if not columns:
        # Agar exact match nahi mila, toh partial match check karein
        for key in DOMAINS.keys():
            if key.lower() in domain_name.lower() or domain_name.lower() in key.lower():
                columns = DOMAINS[key]
                break
    
    if not columns:
        raise ValueError(f"Domain '{domain_name}' not found in DOMAINS dictionary!")

    data = []
    for _ in range(rows):
        row = []
        for col in columns:
            col_lower = col.lower()

            # 1. Names (Covering all roles)
            if any(x in col_lower for x in ["name", "customer", "patient", "employee", "client", "artist", "member", "developer", "lawyer"]):
                row.append(fake.name())

            # 2. Contact Info
            elif "email" in col_lower:
                row.append(fake.email())
            elif "phone" in col_lower or "mobile" in col_lower:
                row.append(fake.phone_number())

            # 3. Dates
            elif any(x in col_lower for x in ["date", "check-in", "deadline", "joining", "hearing"]):
                row.append(fake.date())

            # 4. IDs & Codes
            elif any(x in col_lower for x in ["id", "roll", "account", "emp", "case", "flight", "license"]):
                row.append(fake.bothify(text='??-#####').upper())

            # 5. Financials (Money)
            elif any(x in col_lower for x in ["salary", "balance", "price", "fees", "budget", "bill", "cost", "premium"]):
                row.append(round(random.uniform(500, 95000), 2))

            # --- Domain Specific Logic (Gym, Pharmacy, Agency, Law, etc.) ---
            
            # Software Agency / IT
            elif any(x in col_lower for x in ["project", "tech stack", "platform"]):
                row.append(random.choice(["E-Commerce App", "AI Chatbot", "Portfolio Web", "React", "Python", "Node.js"]))
            
            # Pharmacy / Medical
            elif any(x in col_lower for x in ["medicine", "test", "result", "dosage", "disease"]):
                row.append(random.choice(["Paracetamol", "Insulin", "Blood Test", "MRI Scan", "COVID-19", "Negative", "500mg"]))
            
            # Gym / Fitness / Sports
            elif any(x in col_lower for x in ["plan", "membership", "workout", "sport", "team"]):
                row.append(random.choice(["Monthly Gold", "Yearly Platinum", "Zumba", "Yoga", "Cricket", "Football"]))
            
            # Law / Police / Status
            elif any(x in col_lower for x in ["crime", "status", "category", "scheme"]):
                row.append(random.choice(["Pending", "Closed", "Active", "Under Review", "Cyber Fraud", "Theft"]))
            
            # Education
            elif any(x in col_lower for x in ["course", "subject", "semester", "class"]):
                row.append(random.choice(["B.Tech CS", "MBA", "Physics", "Chemistry", "Semester 3", "Grade 10"]))
            
            # Locations
            elif any(x in col_lower for x in ["city", "source", "destination", "branch", "location", "area"]):
                row.append(fake.city())

            # Gender
            elif "gender" in col_lower:
                row.append(random.choice(["Male", "Female", "Other"]))

            # Default
            else:
                row.append(fake.word().title())

        data.append(row)

    df = pd.DataFrame(data, columns=columns)

    # File Save Logic
    output_dir = "generated_data"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Safe Filename
    safe_filename = domain_name.replace("/", "_").replace(" ", "_")
    file_path = os.path.join(output_dir, f"{safe_filename}_data.csv")
    df.to_csv(file_path, index=False)
    
    return df